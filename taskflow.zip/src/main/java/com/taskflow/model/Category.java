package com.taskflow.model;

public enum Category {
    WORK,
    PERSONAL,
    STUDY,
    HEALTH,
    FINANCE,
    SHOPPING,
    GENERAL
}
