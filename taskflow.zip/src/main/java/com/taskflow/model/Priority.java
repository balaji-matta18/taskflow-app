package com.taskflow.model;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}
